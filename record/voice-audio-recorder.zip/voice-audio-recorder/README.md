# AudioRecorder
In-browser audio recorder that uses system's microphone to record up to 5 minutes of content and encode into .wav file. File can be downloaded on any device.

## Technologies Used
1. MediaRecorder Web API
2. jQuery v 3.6.0

## Hosted on gh-pages
